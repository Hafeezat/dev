<!DOCTYPE html>
<html>
    <head>
        <title>Devops</title>
    </head>
    <body>
        <?php
            include_once('connect.php')
            ?>
    </body>
</html>